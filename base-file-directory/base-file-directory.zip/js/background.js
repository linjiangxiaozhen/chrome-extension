function findCurrentUrl() {
    alert(1);
}