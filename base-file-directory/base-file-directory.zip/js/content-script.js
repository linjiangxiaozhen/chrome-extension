var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver
// 选择目标节点
var target = $(".ebase-Frame__main")[0];
// 创建观察者对象
var observer = new MutationObserver(function (mutations) {
    // mutations.forEach(function(mutation) {
    //     console.log(mutation.type);
    // });
    setTimeout(function() {
        if ($(".mc-marketMonitor").length > 0) {
            if ($(".mc-marketMonitor").find(".fengji_tool").length <= 0) {
                $(".mc-marketMonitor").find(".oui-card-header").eq(0).append("<div id=\"xuyefeiTest\" style=\"background:#ffddee;" +
                    ";display: inline;float:left;margin: 0px 30px;padding: 0px 10px\" " +
                    "class=\"fengji_tool marketMyMonitorCardHotshop_btnGroup\"><span>叶飞测试：</span>" +
                    "<button class=\"layui-btn\" " +
                    "style=\"\" title=\"叶飞测试：\" onclick='openDataDialog(this)'>一键转化</button></div>");
            }
        }
    },2000);
});
// 配置观察选项:
var config = {attributes: true, subtree: true, characterData: true}
// 传入目标节点和观察选项
observer.observe(target, config);
// 随后,你还可以停止观察
//observer.disconnect();
$(() => {
// 向页面注入JS
    injectCss("layui/css/layui.css");
    injectCss("css/myself.css");
    injectJs("js/jquery.min.js");
    injectJs("layui/layui.all.js");
    injectJs("js/crypto-js.min.js");
    injectJs("js/inject.js");
    // injectJs("js/my_test.js");
})

// 向页面注入JS
function injectJs(jsPath) {
    jsPath = jsPath || 'js/inject.js';
    var temp = document.createElement('script');
    temp.setAttribute('type', 'text/javascript');
    // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
    temp.src = chrome.extension.getURL(jsPath);
    temp.onload = function () {
        // 放在页面不好看，执行完后移除掉
        this.parentNode.removeChild(this);
    };
    document.head.appendChild(temp);
}

function injectCss(cssPath) {
    var temp = document.createElement('link');
    temp.setAttribute('rel', 'stylesheet');
    // 获得的地址类似：chrome-extension://ihcokhadfjfchaeagdoclpnjdiokfakg/js/inject.js
    temp.href = chrome.extension.getURL(cssPath);
    temp.onload = function () {
        // 放在页面不好看，执行完后移除掉
        //this.parentNode.removeChild(this);
    };
    document.head.appendChild(temp);
}