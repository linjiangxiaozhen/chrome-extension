var sycmFieldDefine = {
    '交易指数': 'tradeIndex',
    '流量指数': 'uvIndex',
    '点击人气': 'clickHits',
    '搜索人气': 'seIpvUvHits',
    '收藏人气': 'cltHits',
    '加购人气': 'cartHits',
    '支付转化指数': 'payRateIndex',
    '客群指数': 'payByrCntIndex',
    '预售定金交易指数': 'prePayAmtIndex',
    '搜索热度': 'sePvIndex',
    '预售定金指数': 'preTradeIndex',
    '支付商品数指数': 'paidItemCntIndex',
    '下单买家指数': 'crtByrCntIndex',
    '下单转化指数': 'crtRateIndex',
    '支付买家指数': 'payOrderByrCntIndex',
    '流失指数': 'lostIndex',
    '流失人气': 'lostHits',
    '加购人数': 'addCartUserCnt',
    '预售定金商品件数': 'preSellItmCnt',
    '交易金额': 'trade',
    '访客人数': 'uv',
    '点击人数': 'clickHits',
    '点击热度': 'clickHot',
    '搜索次数': 'sePv',
    '搜索人数': 'spvRatio',
    '收藏人数': 'cltByrCnt',
    '支付转化率': 'payRate',
    '支付人数': 'payByrCnt',
    '客单价': 'perTicketSales',
    'uv价值': 'uvValue',
    '支付件数': 'payItemCnt',
    '支付买家数': 'payBuyerCnt',
    '搜索占比': 'seIpvUvHitsRate',
    '收藏率': 'cltCntRate',
    '加购率': 'addCartRate',
    '支付商品数': 'payItemCnt',
    '卖家数': 'slrCnt',
    '有支付卖家数': 'paySlrCnt',
    '预售定金': 'prePayAmt',
    '预售支付商品件数': 'prePayItmCnt',
    '上新商品数': 'fstOnsItmCnt',
    '热搜排名': 'hotSearchRank',
    '飙升排名': 'soarRank',
    '点击率': 'clickRate',
    '直通车参考价': 'p4pAmt',
    '相关搜索词数': 'relSeWordCnt',
    '相关词搜索人气': 'avgWordSeIpvUvHits',
    '相关词点击人气': 'avgWordClickHits',
    '词均点击率': 'avgWordClickRate',
    '词均支付转化率': 'avgWordPayRate',
    '词均支付人数': 'avgWordPayByrCnt',
    '词均搜索增长幅度': 'avgWordSeRiseRate',
    '搜索增长幅度': 'seRiseRate',
    '交易增长幅度': 'tradeGrowthRange',
    '流失金额': 'payLostAmt',
    '流失人数': 'losByrCnt',
    '流失率': 'losRate',
    '收藏后流失人数': 'cltLosByrCnt',
    '加购后流失人数': 'cartLosByrCnt',
    '收藏后跳失人数': 'cltJmpByrCnt',
    '加购后跳失人数': 'cartJmpByrCnt',
    '直接跳失人数': 'directLosCnt',
    '引起流失商品数': 'losItmCnt',
    '引起流失店铺数': 'losShopCnt',
    '本店商品搜索引导访客数': 'seGuideUv',
    '竞品平均搜索引导访客数': 'rivalItmAvgSeGuideUv',
    '本店商品搜索引导加购人数': 'seGuideCartByrCnt',
    '竞品平均搜索引导加购人数': 'rivalItmAvgSeGuideCartByrCnt',
    '本店商品搜索引导支付买家数': 'seGuidePayByrCnt',
    '竞品平均搜索引导支付买家数': 'rivalItmAvgSeGuidePayByrCnt',
    '本店商品搜索引导支付转化率': 'seGuidePayRate',
    '竞品平均搜索引导支付转化率': 'rivalItmAvgSeGuidePayRate',
    '支付子订单数较父行业占比': 'payCntParentCateRate',
    '支付金额较父行业占比': 'payAmtParentCateRate',
    '父行业交易金额': 'parentTrade',
    '父行业卖家数占比': 'parentCateSlrRate',
    '父行业卖家数': 'parentCateSlrCnt',
    '有交易卖家数': 'tradeSlrCnt',
    '父行业有交易卖家数': 'parentCateTradeSlrCnt',
    '父行业有交易卖家数占比': 'parentCateTradeSlrCntRate',
    '平均卖家交易金额': 'realAvgTradeIndex',
    '点击人数占比': 'clickHitsRatio',
    '点击次数': 'clickHot',
    '点击次数占比': 'clickCntRatio',
    '一口价': 'discountPrice',
    '促销价': 'discountPrice',
    '搜索人数/在线商品数': 'spvRatio_onlineGoodsCnt',
    '交易金额/在线商品数': 'trade_onlineGoodsCnt',
    '商城点击占比': 'tmClickRatio',
    '关键词数': 'keywordCount',
    '在线商品数': 'onlineGoodsCnt',
    '浏览量': 'pv',
    '浏览量(占比)': 'pvRatio',
    '收藏次数': 'cltTimes',
    '加购次数': 'cartTimes',
    '行业排名': 'cateRankId',
    '类目交易金额': 'cate_tradeIndex',
    '全店交易金额': 'shop_tradeIndex',
    '类目访客人数': 'cate_uvIndex',
    '全店访客人数': 'shop_uvIndex',
    '类目搜索人数': 'cate_seIpvUvHits',
    '全店搜索人数': 'shop_seIpvUvHits',
    '类目支付人数': 'cate_payByrCntIndex',
    '全店支付人数': 'shop_payByrCntIndex',
    '交易金额占比': 'tradeIndexRatio',
    '访客人数占比': 'uvIndexRatio',
    '搜索人数占比': 'seIpvUvHitsRatio',
    '支付人数占比': 'payByrCntIndexRatio',
    '支付商品数占比': 'payItemCntRatio',
    '有支付卖家数占比': 'paySlrCntRatio',
    '热榜指数': 'score',
    '关键词': 'keyword',
    '类目名': 'cateName',
    '支付子订单数较父行业占比增长幅度': 'payCntParentCateRateCycleCqc',
    '支付金额较父行业占比增长幅度': 'payAmtParentCateRateCycleCqc',
    '父行业类目名': 'parentCateName',
    '日期': 'dateRange',
    '类目ID': 'cateId',
    '区域ID': 'areaId',
    '省': 'areaName',
    '客群占比': 'payByrCntRate',
    '属性': 'attrType',
    '属性名称': 'attrName',
    '价格带': 'priceSegName',
    '人群属性': 'crowdAttr',
    '热搜词': 'pageName',
    '总访客人数': 'totalUv',
    '件单价': 'price',
    '点击用户占比': 'proportion',
    '总交易金额': 'totalTrade',
    '搜索竞争商品数': 'seRivalItmCnt',
    '较昨日': 'contrastYesterdayRatio',
    '较上周': 'contrastYesterweekRatio',
    '较上月': 'contrastYestermonthRatio',
    '人均浏览量': 'avgPv',
    '支付子订单数': 'payOrdCnt',
    '人均支付件数': 'avgPayByrCnt',
    '商品浏览量': 'itmPv',
    '支付金额': 'payAmt',
    '支付金额占比': 'payAmtRatio',
    '访问加购转化率': 'visitCartRate',
    '访问收藏转化率': 'visitCltRate',
    '下单金额': 'crtAmt',
    '下单买家数': 'crtByrCnt',
    '下单件数': 'crtItmQty',
    '下单转化率': 'crtRate',
    '商品加购人数': 'itemCartByrCnt',
    '商品加购件数': 'itemCartCnt',
    '商品收藏人数': 'itemCltByrCnt',
    '商品详情页跳出率': 'itmBounceRate',
    '详情页跳出人数': 'itmBounceCnt',
    '商品平均停留时长': 'itmStayTime',
    '平均停留时长': 'stayTime',
    '商品访客数': 'itmUv',
    '聚划算支付金额': 'juPayAmt',
    '支付新买家数': 'newPayByrCnt',
    '老买家支付金额': 'olderPayAmt',
    '支付老买家数': 'payOldByrCnt',
    '未支付买家数': 'unpayByrCnt',
    '访客平均价值': 'uvAvgValue',
    '有访问商品数': 'visitedItemCnt',
    '有支付商品数': 'paidItemCnt',
    '售中售后成功退款金额': 'sucRefundAmt',
    '流失客单价': 'lostPerTicketSales',
    '搜索竞争指数': 'seRivalIndex',
    '搜索交易指数': 'sePayAmtIndex',
    '搜索加购指数': 'seCartIndex',
    '搜索收藏指数': 'seCltIndex',
    '搜索加购率': 'seAddCartRate',
    '搜索收藏率': 'seCltCntRate',
    '搜索引导支付转化率': 'seGuidePayRate',
    '月累计支付金额': 'mtdPayAmt',
    '年累计支付金额': 'ytdPayAmt',
    '月累计支付件数': 'mtdPayItmCnt',
    '新词热度': 'newWordHot',
    '新词增长幅度': 'newWordRiseRate',
    '市场容量': 'marketCapacity',
    '竞争力': 'competitive',
    '成交金额同比': 'tradeIndexSyncCrc',
    '成交金额占比': 'tradeIndexRatio',
    '成交人数同比': 'payByrCntIndexSyncCrc',
    '成交人数占比': 'payByrCntIndexRatio',
    '直接支付买家数': 'directPayByrCnt',
    '粉丝支付买家数': 'fansPayByrCnt',
    '收藏商品-支付买家数': 'cltItmPayByrCnt',
    '收藏商品买家数': 'cltItmByrCnt',
    '加购商品-支付买家数': 'ordItmPayByrCnt',
    '店内跳转人数': 'jpSelfUv',
    '跳出本店人数': 'jpUv',
    '加购件数': 'cartCnt',
    '关注店铺人数': 'shopCltByrCnt',
    '新访客数': 'newUv',
    '老访客数': 'oldUv',
    '跳失率': 'bounceRate',
    '商品跳失率': 'itmJmpRate',
    '访客人数同比': 'uvCycleCrc',
    '下单买家数同比': 'crtByrCntCycleCrc',
    '下单转化率同比': 'crtRateCycleCrc',
    '下单金额同比': 'crtVldAmtCycleCrc',
    '支付金额同比': 'payAmtCycleCrc',
    '支付买家数同比': 'payByrCntCycleCrc',
    '支付转化率同比': 'payRateCycleCrc',
    '新访客数同比': 'newUvCycleCrc',
    '浏览量同比': 'pvCycleCrc',
    '人均浏览量同比': 'avgPvCycleCrc',
    '收藏人数同比': 'cltCntCycleCrc',
    '加购人数同比': 'cartByrCntCycleCrc',
    '跳失率同比': 'bounceRateCycleCrc',
    '曝光量': 'impsCnt',
    '曝光量同比': 'impsCntCycleCrc',
    '页面名称': 'pageTitle',
    '引导支付买家数': 'lePayByrCnt',
    '引导支付买家数同比': 'lePayByrCntCycleCrc',
    '引导支付金额': 'lePayAmt',
    '引导支付金额同比': 'lePayAmtCycleCrc',
    '引导下单买家数': 'leOrderByrCnt',
    '引导下单买家数同比': 'leOrderByrCntCycleCrc',
    '引导下单转化率': 'leOrderRate',
    '引导支付件数': 'payOrdItm',
    '点击人数同比': 'clickHitsCycleCrc',
    '加购指数': 'addCartIndex',
    '带来的访客数': 'iuv',
    '带来的浏览量': 'ipv',
    '有效播放次数': 'playValidCnt',
    '有效播放人数': 'playValidUv',
    '人均播放时长(秒)': 'playTimeAvg',
    '引导收藏商品数': 'leadCltItemCnt',
    '引导支付商品数': 'leadPayItemCnt',
    '引导支付转化率': 'lePayRate',
    '新增粉丝数': 'flwMbrAddCnt',
    '内容互动人数': 'snsMbrCnt',
    '引导进店人数': 'contentGuideShopUv',
    '引导加购人数': 'contentGuideCartByr',
    '商品曝光次数': 'itmExpPv',
    '进店次数': 'guideInPv',
    '进店人数': 'guideInUv',
    '进店潜客数': 'guideInPotUv',
    '进店新客数': 'guideInNewUv',
    '进店老客数': 'guideInOldUv',
    '引导支付子订单数': 'contentGuidePayOrdCnt',
    '内容发布数': 'vedioPubCnt',
    '互动人数': 'mbrUv',
    '互动率': 'mbrRate',
    '转粉率': 'toFansRate',
    '进店率': 'shopInsideRate',
    '30天引导进店人数': 'recent30GuideShopUv',
    '30天进店率': 'recent30ShopInsideRate',
    '30天引导加购人数': 'recent30GuideCartByrCnt',
    '30天加购率': 'recent30GuideCartRate',
    '引导成交人数': 'watchPayCnt',
    '引导成交金额': 'watchPayAmt',
    '成交率': 'watchPayRate',
    '无线成交率': 'wirelessPayRate',
    '引导下单金额': 'leOrderAmt',
    '商品收藏次数': 'cltItmTimes',
    '内容浏览人数': 'contentUv',
    '内容浏览次数': 'contentPv',
    '内容互动次数': 'snsItctCnt',
    '引导进店次数': 'contentGuideShopPv',
    '引导支付人数': 'contentGuidePayOrdByr',
    '累计粉丝数': 'sumFansCnt',
    '偏好人数': 'perferNum'
}

// aes解密，localStorage中的json数据可用此方法解密
function decrypt(word) {
    var key = CryptoJS.enc.Utf8.parse("w28Cz694s63kBYk4");
    var iv = CryptoJS.enc.Utf8.parse("4kYBk36s496zC82w");
    var encryptedHexStr = CryptoJS.enc.Hex.parse(word);
    var srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
    var decrypt = CryptoJS.AES.decrypt(srcs, key, {
        iv: iv,
        padding: CryptoJS.pad.Pkcs7
    });
    var decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
    return decryptedStr.toString();
}

// 指数计算公式,待拟合：y = -2.73E-09x3 + 8.46E-05x2 + 8.38E-02x - 9.53E+00
function caculateFormula(value, tanslateType, fixedLength) {
    if (tanslateType == 1) {
        return Number((-2.73 * Math.pow(10, -9) * Math.pow(value, 3) + 8.46 * Math.pow(10, -5) * Math.pow(value, 2) +
            8.38 * Math.pow(10, -2) * value - 9.53).toFixed(fixedLength));
    } else {
        return Number((-9 * Math.pow(10, -10) * Math.pow(value, 3) + Math.pow(10, -5) * Math.pow(value, 2) +
            0.0017 * value - 0.03678).toFixed(fixedLength));
    }
}

/**
 * @Author xuyefei
 * @Description  将解密后的数据转换成layui表格需要展现的数据
 * @Date 11:22 2020/6/16
 * @Param
 * @return
 **/
function translateJsonDataToDisplay(decodedJsonData) {
    $.each(decodedJsonData, function (index, data) {
        // for (var p in data) {
        //     if (p != "cateRankId" && p != "shop") {
        //         if (typeof data[p]["value"] != "undefined") {
        //             var tanslateType = 1;
        //             if (p == "payRateIndex") {
        //                 tanslateType = 0;
        //             }
        //             data[p + "_real_value"] = Math.round(caculateFormula(data[p]["value"], tanslateType));
        //         }
        //     } else {
        //         if (p == "cateRankId") {
        //             if (typeof data[p]["value"] == "undefined" || data[p]["value"] == null) {
        //                 data[p + "_real_value"] = 0;
        //             } else {
        //                 data[p + "_real_value"] = data[p]["value"];
        //             }
        //         }
        //         if (p == "shop") {
        //             data["shopName"] = data[p]['title'];
        //             data["shopPictureUrl"] = data[p]['pictureUrl'];
        //         }
        //     }
        // }
        // 收藏人气:cltHits---->收藏人数：cltByrCnt
        data['cltByrCnt'] = caculateFormula(data['cltHits']['value'], 1, 0);
        // 支付转化指数：payRateIndex---->支付转化率：payRate
        data['payRate'] = caculateFormula(data['payRateIndex']['value'], 0, 2);
        // 店铺信息
        data['shopName'] = data.shop.title;
        data['shopPictureUrl'] = data.shop.pictureUrl;
        // 搜索人气：seIpvUvHits---->搜索人数：seIpvUvCnt
        data['seIpvUvCnt'] = caculateFormula(data['seIpvUvHits']['value'], 1, 0);
        // 行业排名：cateRankId
        if (typeof data['cateRankId']['value'] != "undefined") {
            data['cateRankValue'] = data['cateRankId']['value'];
            // 升降名次
            if (typeof data['cateRankId']['cycleCqc'] == "undefined" || data['cateRankId']['cycleCqc'] == null) {
                data['cateRankCycleCqc'] = "--";
            } else {
                var cycleCqc = data['cateRankId']['cycleCqc']
                if (cycleCqc == 0) {
                    data['cateRankCycleCqc'] = "持平";
                } else if (cycleCqc > 0) {
                    data['cateRankCycleCqc'] = "降" + cycleCqc + "名";
                } else {
                    data['cateRankCycleCqc'] = "升" + (-cycleCqc) + "名";
                }
                // data['cateRankCycleCqc'] = data['cateRankId']['cycleCqc'];
            }
        } else {
            data['cateRankValue'] = 0;
            data['cateRankCycleCqc'] = "--";
        }
        // 流量指数：uvIndex---->访客人数：uvCnt
        data['uvCnt'] = caculateFormula(data['uvIndex']['value'], 1, 0);
        // 交易指数：tradeIndex---->交易额:tradeCnt
        data['tradeCnt'] = caculateFormula(data['tradeIndex']['value'], 1, 0);
        // 加购人气：cartHits---->加购人数：cartCnt
        data['cartCnt'] = caculateFormula(data['cartHits']['value'], 1, 0);
        // 支付人数
        data['payByrCnt'] = Math.round(data['uvCnt'] * data['payRate']);
        // 客单价
        data['perTicketSales'] = data['payByrCnt'] == 0 ? 0 : Math.round(data['tradeCnt'] / data['payByrCnt']);
        // 收藏率
        data['cltCntRate'] = data['uvCnt'] == 0 ? 0 : (data['cltByrCnt'] / data['uvCnt'] * 100).toFixed(2);
        // 搜索占比
        data['seIpvUvHitsRate'] = data['uvCnt'] == 0 ? 0 : (data['seIpvUvCnt'] / data['uvCnt'] * 100).toFixed(2);
        // 加购率
        data['addCartRate'] = data['uvCnt'] == 0 ? 0 : (data['cartCnt'] / data['uvCnt'] * 100).toFixed(2);
        // UV价值
        data['uvValue'] = data['uvCnt'] == 0 ? 0 : Math.round(data['tradeCnt'] / data['uvCnt']);
    });
    // $.each(decodedJsonData, function (index, data) {
    //     // 支付人数
    //     data['payByrCnt'] = data['uvIndex_real_value'] * data['payRateIndex_real_value'];
    //     // 客单价
    //     data['perTicketSales'] = data['payByrCnt'] == 0 ? 0 : Math.round(data['tradeIndex_real_value'] / data['payByrCnt']);
    //     // 收藏率
    //     data['cltCntRate'] = data['uvIndex_real_value'] == 0 ? 0 : (data['cltHits_real_value'] / data['uvIndex_real_value'] * 100).toFixed(2);
    //     // 搜索占比
    //     data['seIpvUvHitsRate'] = data['uvIndex_real_value'] == 0 ? 0 : (data['seIpvUvHits_real_value'] / data['uvIndex_real_value'] * 100).toFixed(2);
    //     // 加购率
    //     data['addCartRate'] = data['uvIndex_real_value'] == 0 ? 0 : (data['cartHits_real_value'] / data['uvIndex_real_value'] * 100).toFixed(2);
    //     // UV价值
    //     data['uvValue'] = data['uvIndex_real_value'] == 0 ? 0 : Math.round(data['tradeIndex_real_value'] / data['uvIndex_real_value']);
    // })
}

/**
 * @Author xuyefei
 * @Description  关键字检索
 * @Date 11:33 2020/6/18
 * @Param
 * @return
 **/
function searchByKeyword(keyword, tableId) {
    // var tableCacheData = layui.table.cache[tableId];
    // 定义过滤后的数据
    var filterDataArray = [];
    // 遍历所有表格数据
    for (var index in dialogOptions.totalPageData) {
        // 遍历每一个json对象的所有字段
        var tableRowData = dialogOptions.totalPageData[index];
        // recursiveFieldSearch(keyword, tableRowData, filterDataArray, tableRowData);
        for (var field in tableRowData) {
            if (typeof tableRowData[field] != "object" && typeof tableRowData[field] != "undefined"
                && field != "shopPictureUrl") {
                if (String(tableRowData[field]).indexOf(keyword) != -1) {
                    // console.log("tableRowData[field]:" + tableRowData[field] + "---" + field + "----" + keyword);
                    filterDataArray.push(tableRowData);
                    break;
                }
            }
        }
    }
    layui.table.reload(tableId, {
        data: filterDataArray
    })
}

/**
 * @Author xuyefei
 * @Description  递归遍历字段直至叶子节点
 * @Date 14:19 2020/6/18
 * @Param
 * @return
 **/
function recursiveFieldSearch(keyword, obj, filterDataArray, tableRowData) {
    for (var field in obj) {
        if (typeof obj[field] == "object") {
            if (recursiveFieldSearch(keyword, obj[field], filterDataArray, tableRowData)) {
                return;
            }
        } else {
            if (typeof obj[field] != "undefined") {
                try {
                    if (String(obj[field]).indexOf(keyword) != -1) {
                        filterDataArray.push(tableRowData);
                        return true;
                    }
                } catch (error) {

                }
            }
        }
    }
}

/**
 * @Author xuyefei
 * @Description  组装打开窗口所需要的所有数据
 * @Date 10:26 2020/6/22
 * @Param
 * @return
 **/
function assembleDialogOptions() {
    var currentUrl, tabText = $(".mc-marketMonitor .oui-tab-switch-item-active").text();
    var openDialogTitle = "监控" + tabText + " |";
    switch (tabText) {
        case "商品":
            currentUrl = "/mc/ci/item/monitor/list.json";
            break;
        case "店铺":
            currentUrl = "/mc/ci/shop/monitor/list.json";
            break;
    }
    // 1、cateId
    var cateId = $("div[class*='industry-index-wrapper'][class*='active']").find(".cell-links a").attr("href").split("=")[1];
    dialogOptions.cateId = cateId;
    // 2、dateRange
    openDialogTitle += $(".oui-date-picker-current-date").text().replace("统计时间", "") + " | ";
    var dateRange = $(".oui-date-picker-current-date").text().replace("统计时间", "")
        .replace(/\s+/g, "").replace("~", "|");
    if (dateRange.indexOf("|") == -1) {
        dateRange = dateRange + "|" + dateRange;
    }
    dialogOptions.dateRange = dateRange;
    // 3、dateType
    var dateType = $(".oui-date-picker-particle-button .ant-btn-primary").text();
    switch (dateType) {
        case "7天":
            dateType = "recent7";
            break;
        case "30天":
            dateType = "recent30";
            break;
        case "日":
            dateType = "day";
            break;
    }
    dialogOptions.dateType = dateType;
    // 4、device
    var device = $(".fa-common-filter-device-select .ant-select-selection-selected-value").text();
    openDialogTitle += device;
    dialogOptions.openDialogTitle = openDialogTitle;
    switch (device) {
        case "所有终端":
            device = "0";
            break;
        case "PC端":
            device = "1";
            break;
        case "无线端":
            device = "2";
            break;
    }
    dialogOptions.device = dateType;
    // 5、sellType
    var sellType = $(".sellerType-select .ant-select-selection-selected-value").text();
    switch (sellType) {
        case "全部":
            sellType = "-1";
            break;
        case "天猫":
            sellType = "1";
            break;
        case "淘宝":
            sellType = "0";
            break;
    }
    dialogOptions.sellType = sellType;
    // 6、分页和排序参数
    var pageSize = $(".mc-marketMonitor .oui-page-size-select .ant-select-selection-selected-value").text();
    var pageNo = $(".mc-marketMonitor .alife-dt-card-common-table-pagination-wrapper .ant-pagination-item-active").text();;
    var maxPageNo;
    if (typeof pageNo == "undefined" || pageNo == null || pageNo == "") {
        pageNo = 1;
        maxPageNo = 1;
    } else {
        maxPageNo = $(".mc-marketMonitor .alife-dt-card-common-table-pagination-wrapper .ant-pagination-item:last").text();
    }
    var order = "asc", orderBy = "tradeIndex";
    var activeOrderFieldDom = $(".mc-marketMonitor .ant-table-body thead").find(".alife-dt-card-common-table-sortable-icon-wrapper i[class*='active']");
    if (activeOrderFieldDom.attr('class').indexOf("up") != -1) {
        order = "asc";
    } else if (activeOrderFieldDom.attr('class').indexOf("down") != -1) {
        order = "desc";
    }
    var orderByText = activeOrderFieldDom.parent().prev().text();
    if (orderByText == "行业排名") {
        orderBy = "cateRankId";
    } else if (orderByText == "交易指数") {
        orderBy = "tradeIndex";
    } else if (orderByText == "流量指数") {
        orderBy = "uvIndex";
    }
    dialogOptions.pageNo = pageNo;
    dialogOptions.maxPageNo = maxPageNo;
    dialogOptions.pageSize = pageSize;
    dialogOptions.order = order;
    dialogOptions.orderBy = orderBy;
    dialogOptions.cachePageData = {};
    // 从缓存中查找所有分页的数据
    currentUrl += "?cateId=" + cateId + "&dateRange=" + dateRange + "&dateType=" + dateType + "&device=" + device
        + "&indexCode=cateRankId,tradeIndex,uvIndex&order=" + order + "&orderBy=" + orderBy + "&page=" + pageNo + "&pageSize="
        + pageSize + "&sellerType=" + sellType;
    dialogOptions.currentUrl = currentUrl;
    resetCacheData();
}

/**
 * @Author xuyefei
 * @Description  重新设置弹出框需要的缓存数据：保存每一页的数据和组装所有页面数据的集合
 * @Date 14:11 2020/6/22
 * @Param
 * @return
 **/
function resetCacheData() {
    dialogOptions.cachePageData = {};
    dialogOptions.totalPageData = [];
    for (var i = 1; i <= dialogOptions.maxPageNo; i++) {
        var cacheUrl = dialogOptions.currentUrl.replace(/&page=\S+&pageSize/, "&page=" + i + "&pageSize");
        var localCacheDataByUrl = localStorage.getItem(cacheUrl);
        if (localCacheDataByUrl != null) {
            var formatJsonData = localCacheDataByUrl.replace(/\d+\|/, "").replace(/\\"/g, "\"");
            var jsonData = $.parseJSON(formatJsonData.substr(1, formatJsonData.length - 2));
            var decodeJsonData = $.parseJSON(decrypt(jsonData['value']['_d']));
            translateJsonDataToDisplay(decodeJsonData.data);
            dialogOptions.cachePageData[String(i)] = decodeJsonData.data;
            dialogOptions.totalPageData = dialogOptions.totalPageData.concat(decodeJsonData.data);
        }
    }
}

/**
 * @Author xuyefei
 * @Description  为关键字搜索绑定事件
 * @Date 14:20 2020/6/22
 * @Param
 * @return
 **/
function bindEventForKeywordSearch() {
    $("body").on("compositionstart", "#searchKeyword", function () {
        inputCompletedFlag = false;
    });
    $("body").on("compositionend", "#searchKeyword", function () {
        inputCompletedFlag = true;
    });
    $("body").on("input propertychange", "#searchKeyword", function () {
        var __this = this;
        setTimeout(function () {
            if (inputCompletedFlag) {
                dialogOptions.searchKeyword = $("#searchKeyword").val();
                searchByKeyword($(__this).val(), "test_table");
            }
        }, 10);
    });
}

/**
 * @Author xuyefei
 * @Description  渲染分页栏
 * @Date 9:25 2020/6/23
 * @Param
 * @return
 **/
function renderPageBar() {
    layui.laypage.render({
        elem: "pageBar",
        // prev: "&#8592",
        // next: "&#8594",
        layout : ['prev', 'page', 'next'],
        curr: dialogOptions.pageNo,
        limit : dialogOptions.pageSize,
        count: dialogOptions.pageSize * dialogOptions.maxPageNo,
        // limits: [5, 10, 20, 50, 100],
        jump: function (obj, first) {
            // console.log(obj.curr);
            // console.log(first);
            // console.log(obj.limit);
            var pageData;
            if (!first) {
                $(".mc-marketMonitor .alife-dt-card-common-table-pagination-wrapper .ant-pagination-item")
                    .each(function (index) {
                        if (index + 1 == obj.curr) {
                            $(this).trigger("click");
                        }
                    });
                    // .eq(obj.curr - 1).trigger("click");
                pageData = dialogOptions.cachePageData[String(obj.curr)];
                if (pageData == null || typeof pageData == "undefined") {
                    var interval = setInterval(function () {
                        resetCacheData();
                        pageData = dialogOptions.cachePageData[String(obj.curr)];
                        if (pageData != null) {
                            clearInterval(interval);
                            layui.table.reload("test_table", {
                                data: dialogOptions.totalPageData
                            });
                        }
                    }, 100);
                }
            }
            // 页码添加未缓存标志
            $("#pageBar a").each(function(index) {
                var pageNo = $(this).text();
                if (pageNo.indexOf("页") != -1) {
                    return true;
                }
                pageData = dialogOptions.cachePageData[pageNo];
                if (pageData == null || typeof pageData == "undefined") {
                    // $(this).css({"opacity": "0.5", "filter":"alpha(opacity=50)", "background":"gray", "color":"#fff"});
                    $(this).css("position", "relative");
                    $(this).append("<i class='layui-badge-dot' style='position: absolute;top:6px'></i>");
                }
            });
        }
    });
}

/**
 * @Author xuyefei
 * @Description  渲染表格数据
 * @Date 14:25 2020/6/22
 * @Param
 * @return
 **/
function renderTable() {
// 初始化数据表格
    var tableInstance = layui.table.render({
        id: "test_table",
        elem: '#mydemo',
        // ,url: 'http://www.layui.com/demo/table/user' //数据接口
        height: '420',
        data: dialogOptions.totalPageData,
        page: false, //开启分页
        // , limit: 5
        toolbar: "<div>" +
            "<div class=\"layui-input-inline\" style='padding-right: 10px;'><input id='searchKeyword' placeholder='请输入检索关键字' class=\"layui-input\"></div>" +
            "<button style='position: relative;' type=\"button\" class=\"layui-btn layui-btn-primary\" lay-event=\"LAYTABLE_EXPORT\"><i class=\"layui-icon layui-icon-export\"></i>数据导出</button>" +
            "<button style='position: relative' type=\"button\" class=\"layui-btn layui-btn-primary\" lay-event=\"LAYTABLE_COLS\"><i class=\"layui-icon layui-icon-cols\"></i>数据列筛选</button>" +
            "<button style='position: relative' type=\"button\" class=\"layui-btn layui-btn-primary\" lay-event=\"LAYTABLE_PRINT\"><i class=\"layui-icon layui-icon-print\"></i>打印</button>" +
            // "<div class=\"layui-inline\" title=\"数据导出\" lay-event=\"LAYTABLE_EXPORT\" style=\"width: auto;\"><i class=\"layui-icon layui-icon-export\"></i> 数据导出</div>" +
            // "<div class=\"layui-inline\" title=\"数据列筛选\" lay-event=\"LAYTABLE_COLS\" style=\"width: auto;\"><i class=\"layui-icon layui-icon-cols\"></i> 数据列筛选</div>" +
            // "<div class=\"layui-inline\" title=\"打印\" lay-event=\"LAYTABLE_PRINT\" style=\"width: auto;\"><i class=\"layui-icon layui-icon-print\"></i> 打印</div>" +
            "</div>",
        defaultToolbar: [],
        cols: [[ //表头
            {
                field: 'shopName',
                title: '店铺名称',
                templet: function (row) {
                    return "<img src='" + row.shopPictureUrl + "' style='width: 17px;height: 17px'/><span>" + row.shopName + "</span>";
                },
                width: "15%"
            }, {
                field: 'cateRankValue',
                title: '行业排名',
                sort: true,
                templet: function (obj) {
                    var rankDisplayValue, cycleCqcValue,
                        displayHtml = "<div style='width: 50px;text-align: left;display: inline-block;'>" + obj.cateRankValue + "</div>" +
                            "<div style='width: 50px;text-align: left;" +
                            "display: inline-block'>";
                    if (obj.cateRankCycleCqc != "--") {
                        if (obj.cateRankCycleCqc.indexOf("降") != -1) {
                            displayHtml += "<span style='color:green'>" + obj.cateRankCycleCqc + "</span>";
                        } else if (obj.cateRankCycleCqc.indexOf("升") != -1) {
                            displayHtml += "<span style='color:red'>" + obj.cateRankCycleCqc + "</span>";
                        } else {
                            displayHtml += obj.cateRankCycleCqc
                        }
                    } else {
                        displayHtml += obj.cateRankCycleCqc
                    }
                    displayHtml += "</div>";
                    return displayHtml;
                },
                width: "8%"
            }, {
                field: 'tradeCnt',
                title: '交易金额',
                sort: true
            }, {
                field: 'uvCnt',
                title: '访客人数',
                sort: true
            }, {
                field: 'seIpvUvCnt',
                title: '搜索人数',
                sort: true
            }, {
                field: 'cltByrCnt',
                title: '收藏人数',
                sort: true
            }, {
                field: 'cartCnt',
                title: '加购人数',
                sort: true
            }, {
                field: 'payRate',
                title: '支付转化率',
                sort: true,
                width: "8%"
            }
            , {
                field: 'payByrCnt',
                title: '支付人数',
                sort: true
            }
            , {
                field: 'perTicketSales',
                title: '客单价',
                sort: true
            }
            , {
                field: 'cltCntRate',
                title: '收藏率',
                sort: true,
                templet: "<div>{{d.cltCntRate}}%</div>"
            }, {
                field: 'seIpvUvHitsRate',
                title: '搜索占比',
                sort: true,
                templet: "<div>{{d.seIpvUvHitsRate}}%</div>"
            }, {
                field: 'addCartRate',
                title: '加购率',
                sort: true,
                templet: "<div>{{d.addCartRate}}%</div>"
            }, {
                field: 'uvValue',
                title: 'uv价值',
                sort: true
            }
        ]],
        done: function (res, curr, count) {
            $("#searchKeyword").val(dialogOptions.searchKeyword);
            $("#searchKeyword").focus();
        }
    });
}
var dialogOptions = {};
/**
 * @Author xuyefei
 * @Description  打开数据对话框
 * @Date 11:00 2020/6/22
 * @Param
 * @return
 **/
function openDataDialog() {
    layui.layer.open({
        type: 1,
        title: "消息窗口",
        area: ['90%', '550px'],
        shade: 0.3,
        maxmin: false,
        content: "<div id='mydemo'></div><div id='pageBar'></div>",
        zIndex: layui.layer.zIndex,
        shadeClose: true,
        offset: ['100px'],
        end: function () {

        },
        success: function (layero, index) {
            assembleDialogOptions();
            // 重新设置弹出框的标题
            layui.layer.title(dialogOptions.openDialogTitle, index);
            renderPageBar();
            renderTable();
            bindEventForKeywordSearch();
        }
    });
}